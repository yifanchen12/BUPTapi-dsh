#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
NODE_HOME="${DSH_NODE_HOME:-$HOME/.local/share/bupt-dsh/node}"
NODE_BIN="${NODE_BIN:-$NODE_HOME/bin/node}"
DSH_BIN="${DSH_BIN:-$NODE_HOME/bin/dsh}"

if [ ! -x "$NODE_BIN" ]; then
  NODE_BIN="$(command -v node || true)"
fi
if [ ! -x "$DSH_BIN" ]; then
  DSH_BIN="$(command -v dsh || true)"
fi

if [ -z "$NODE_BIN" ] || [ ! -x "$NODE_BIN" ] || [ -z "$DSH_BIN" ] || [ ! -x "$DSH_BIN" ]; then
  echo "未找到 Node.js 或 DSH。请先运行 dsh-download-setup.command。"
  read -r -p "按 Enter 退出。" _
  exit 2
fi

printf '北邮 API → DSH 一键接入\n'
printf '需要：DSH/Node.js、校园 VPN、你自己的 BUPT API Key\n\n'
read -r -s -p '请输入 BUPT API Key（输入不会显示）：' BUPT_API_KEY
printf '\n'
if [ -z "$BUPT_API_KEY" ]; then
  echo 'API Key 不能为空。'
  read -r -p '按 Enter 退出。' _
  exit 1
fi

printf '%s\n' "$BUPT_API_KEY" | BUPT_PROBE=1 "$NODE_BIN" "$SCRIPT_DIR/configure.mjs"
unset BUPT_API_KEY

mkdir -p "${DSH_HOME:-$HOME/.dsh}"
if ! curl -fsS --max-time 1 http://127.0.0.1:3080/ >/dev/null 2>&1; then
  echo '正在启动 DSH Web…'
  nohup "$DSH_BIN" web --port 3080 >"${DSH_HOME:-$HOME/.dsh}/bupt-dsh.log" 2>&1 &
  for _ in $(seq 1 70); do
    if curl -fsS --max-time 1 http://127.0.0.1:3080/ >/dev/null 2>&1; then break; fi
    sleep 0.5
  done
fi

if curl -fsS --max-time 1 http://127.0.0.1:3080/ >/dev/null 2>&1; then
  open http://127.0.0.1:3080
  echo '完成：已打开 http://127.0.0.1:3080'
else
  echo 'DSH 未在预期时间内打开，请查看 ~/.dsh/bupt-dsh.log。'
fi
read -r -p '按 Enter 退出。' _
