import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const BASE_URL = 'https://myai.bupt.edu.cn/llm-gw/v1';
const MODEL = 'deepseek-v4-flash';
const PROVIDER = 'bupt-campus';
const START = '# >>> BUPT DSH provider (managed) >>>';
const END = '# <<< BUPT DSH provider (managed) <<<';
const DEFAULT_START = '# >>> BUPT DSH default model (managed) >>>';
const DEFAULT_END = '# <<< BUPT DSH default model (managed) <<<';

const key = fs.readFileSync(0, 'utf8').split(/\r?\n/, 1)[0].trim();
if (!key) {
  console.error('API Key 不能为空。');
  process.exit(1);
}

const dshHome = path.resolve(process.env.DSH_HOME || path.join(os.homedir(), '.dsh'));
fs.mkdirSync(dshHome, { recursive: true });
const settingsPath = path.join(dshHome, 'settings.yaml');
const credentialsPath = path.join(dshHome, '.credentials.yaml');

backup(settingsPath);
backup(credentialsPath);

let settings = fs.existsSync(settingsPath) ? fs.readFileSync(settingsPath, 'utf8') : '';
settings = removeManaged(settings, START, END);
settings = removeManaged(settings, DEFAULT_START, DEFAULT_END);
settings = mergeProvider(settings);
settings = mergeDefaultModel(settings);
fs.writeFileSync(settingsPath, ensureNewline(settings), 'utf8');

let credentials = fs.existsSync(credentialsPath) ? fs.readFileSync(credentialsPath, 'utf8') : '';
const credentialLine = `BUPT_API_KEY: ${quoteYaml(key)}`;
if (/^BUPT_API_KEY\s*:/m.test(credentials)) {
  credentials = credentials.replace(/^BUPT_API_KEY\s*:\s*.*(?:\r?\n|$)/m, `${credentialLine}\n`);
} else {
  credentials = ensureNewline(credentials) + credentialLine + '\n';
}
fs.writeFileSync(credentialsPath, credentials, 'utf8');

console.log('已合并 DSH 配置和本地凭据（已有模型配置已保留，密钥未显示）。');

if (process.env.BUPT_PROBE === '1') {
  try {
    const response = await fetch(`${BASE_URL}/models`, {
      headers: { Authorization: `Bearer ${key}` },
      signal: AbortSignal.timeout(12000)
    });
    console.log(response.ok
      ? '北邮接口检查通过。'
      : `北邮接口暂不可达：HTTP ${response.status}（仍会继续启动 DSH。）`);
  } catch {
    console.log('北邮接口暂不可达：请确认校园 VPN（仍会继续启动 DSH）。');
  }
}

function mergeProvider(text) {
  const lines = splitLines(text);
  const section = topSection(lines, 'llm-pi-ai:');
  if (section.start < 0) {
    lines.push(
      START,
      'llm-pi-ai:',
      '  providers:',
      ...providerLines('    '),
      END
    );
    return joinLines(lines);
  }

  const providers = directChild(lines, section, 2, 'providers:');
  if (providers < 0) {
    lines.splice(section.start + 1, 0, '  providers:', ...providerLines('    '));
    return joinLines(lines);
  }

  lines.splice(mappingEnd(lines, providers, 2, section.end), 0, ...providerLines('    '));
  return joinLines(lines);
}

function mergeDefaultModel(text) {
  const lines = splitLines(text);
  let section = topSection(lines, 'agent-default-model:');
  if (section.start < 0) {
    lines.push(
      DEFAULT_START,
      'agent-default-model:',
      `  provider: ${PROVIDER}`,
      `  model: ${MODEL}`,
      DEFAULT_END
    );
    return joinLines(lines);
  }

  let provider = directChild(lines, section, 2, 'provider:');
  if (provider >= 0) lines[provider] = `  provider: ${PROVIDER}`;
  else lines.splice(section.start + 1, 0, `  provider: ${PROVIDER}`);

  section = topSection(lines, 'agent-default-model:');
  const model = directChild(lines, section, 2, 'model:');
  if (model >= 0) lines[model] = `  model: ${MODEL}`;
  else lines.splice(section.start + 2, 0, `  model: ${MODEL}`);
  return joinLines(lines);
}

function providerLines(indent) {
  return [
    `${indent}${START}`,
    `${indent}${PROVIDER}:`,
    `${indent}  displayName: 北邮校园模型`,
    `${indent}  apiKeyEnv: BUPT_API_KEY`,
    `${indent}  api: openai-completions`,
    `${indent}  baseURL: ${BASE_URL}`,
    `${indent}  models:`,
    `${indent}    - id: ${MODEL}`,
    `${indent}      name: ${MODEL}`,
    `${indent}      input: [text]`,
    `${indent}      contextWindow: 131072`,
    `${indent}      maxTokens: 8192`,
    `${indent}${END}`
  ];
}

function splitLines(text) {
  const lines = text.replaceAll('\r\n', '\n').split('\n');
  while (lines.at(-1) === '') lines.pop();
  return lines;
}

function joinLines(lines) {
  return lines.join('\n');
}

function topSection(lines, keyName) {
  for (let i = 0; i < lines.length; i++) {
    if (indent(lines[i]) !== 0 || lines[i].trimEnd() !== keyName) continue;
    let end = i + 1;
    while (end < lines.length && (!isTopLevel(lines[end]) || lines[end].trim() === '')) end++;
    return { start: i, end };
  }
  return { start: -1, end: -1 };
}

function directChild(lines, section, expectedIndent, keyName) {
  for (let i = section.start + 1; i < section.end; i++) {
    const trimmed = lines[i].trim();
    if (indent(lines[i]) === expectedIndent && (trimmed === keyName || trimmed.startsWith(`${keyName} `))) return i;
  }
  return -1;
}

function mappingEnd(lines, start, parentIndent, sectionEnd) {
  for (let i = start + 1; i < sectionEnd; i++) {
    if (!lines[i].trim() || lines[i].trimStart().startsWith('#')) continue;
    if (indent(lines[i]) <= parentIndent) return i;
  }
  return sectionEnd;
}

function isTopLevel(line) {
  return Boolean(line.trim()) && indent(line) === 0 && !line.trimStart().startsWith('#');
}

function indent(line) {
  return line.length - line.trimStart(' ').length;
}

function removeManaged(text, start, end) {
  const escape = value => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return text.replace(new RegExp(`${escape(start)}[\\s\\S]*?${escape(end)}\\r?\\n?`, 'g'), '');
}

function backup(file) {
  if (!fs.existsSync(file)) return;
  const stamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d{3}Z$/, '').replace('T', '-');
  let target = `${file}.bupt-backup-${stamp}`;
  let index = 1;
  while (fs.existsSync(target)) target = `${file}.bupt-backup-${stamp}-${index++}`;
  fs.copyFileSync(file, target);
}

function ensureNewline(text) {
  return text && text.endsWith('\n') ? text : `${text}\n`;
}

function quoteYaml(value) {
  return `'${value.replaceAll("'", "''")}'`;
}
