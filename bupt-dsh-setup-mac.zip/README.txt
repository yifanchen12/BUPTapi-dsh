北邮 DSH macOS 一键工具

文件：
- bupt-dsh-setup.command：适合已经安装 Node.js/DSH 的 Mac。
- dsh-download-setup.command：自动下载 Node.js、安装 DSH，然后完成配置。

使用：
1. 解压 ZIP。
2. 双击对应的 .command 文件。
3. 如果 macOS 首次阻止运行，请右键文件，选择“打开”；仍被阻止时在终端执行：
   chmod +x *.command
4. 输入学校发放的 BUPT API Key；输入时不会显示字符。

说明：
- 支持 Apple Silicon（arm64）和 Intel（x86_64）。
- Node.js 从 nodejs.org 官方地址下载，并核对官方 SHA-256。
- DSH 安装到 ~/.local/share/bupt-dsh，不需要 sudo。
- 已有 DSH Provider 会保留，只追加北邮校园模型；原配置会自动备份。
- 校外使用前请连接北京邮电大学校园 VPN。
- API Key 不会写入压缩包、源码或普通日志。
- 这是未签名的 .command 文件，首次运行可能需要手动允许。
