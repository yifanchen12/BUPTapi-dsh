#!/bin/bash
set -euo pipefail

PORT=3080
DSH_HOME="${DSH_HOME:-$HOME/.dsh}"
DSH_BIN="${DSH_BIN:-$HOME/.local/share/bupt-dsh/node/bin/dsh}"

if [ ! -x "$DSH_BIN" ]; then
  DSH_BIN="$(command -v dsh || true)"
fi

if [ -z "$DSH_BIN" ] || [ ! -x "$DSH_BIN" ]; then
  echo '未找到 DSH。请先运行 dsh-download-setup.command 完成安装。'
  read -r -p '按 Enter 退出。' _
  exit 2
fi

mkdir -p "$DSH_HOME"
if ! curl -sS --max-time 1 -o /dev/null "http://127.0.0.1:$PORT/" >/dev/null 2>&1; then
  echo '正在启动 DSH Web…'
  nohup "$DSH_BIN" web --port "$PORT" >"$DSH_HOME/bupt-dsh.log" 2>&1 &
fi

for _ in $(seq 1 70); do
  if curl -sS --max-time 1 -o /dev/null "http://127.0.0.1:$PORT/" >/dev/null 2>&1; then
    open "http://127.0.0.1:$PORT"
    echo "已打开 http://127.0.0.1:$PORT"
    read -r -p '按 Enter 退出。' _
    exit 0
  fi
  sleep 0.5
done

echo "DSH 未在预期时间内打开，请查看 $DSH_HOME/bupt-dsh.log。"
read -r -p '按 Enter 退出。' _
exit 3
