#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
NODE_VERSION="24.19.0"
APP_HOME="$HOME/.local/share/bupt-dsh"
NODE_HOME="${DSH_NODE_HOME:-$APP_HOME/node}"
NODE_BIN="$NODE_HOME/bin/node"
NPM_BIN="$NODE_HOME/bin/npm"
DSH_BIN="$NODE_HOME/bin/dsh"
export PATH="$NODE_HOME/bin:${PATH:-}"
export NPM_CONFIG_PREFIX="$NODE_HOME"

case "$(uname -m)" in
  arm64|aarch64) NODE_ARCH='darwin-arm64' ;;
  x86_64) NODE_ARCH='darwin-x64' ;;
  *) echo "不支持的 Mac 架构：$(uname -m)"; read -r -p '按 Enter 退出。' _; exit 2 ;;
esac

mkdir -p "$APP_HOME"
if [ ! -x "$NODE_BIN" ]; then
  tmp="$(mktemp -d "${TMPDIR:-/tmp}/bupt-dsh.XXXXXX")"
  trap 'rm -rf "$tmp"' EXIT
  archive="node-v${NODE_VERSION}-${NODE_ARCH}.tar.gz"
  base="https://nodejs.org/dist/v${NODE_VERSION}"
  echo "正在下载 Node.js ${NODE_VERSION}（${NODE_ARCH}）…"
  curl -fL --retry 3 --connect-timeout 15 -o "$tmp/$archive" "$base/$archive"
  curl -fsSL --retry 3 -o "$tmp/SHASUMS256.txt" "$base/SHASUMS256.txt"
  expected="$(awk -v name="$archive" '$2 == name { print $1; exit }' "$tmp/SHASUMS256.txt")"
  actual="$(shasum -a 256 "$tmp/$archive" | awk '{print $1}')"
  [ -n "$expected" ] && [ "$expected" = "$actual" ] || { echo 'Node.js SHA-256 校验失败，已中止。'; exit 3; }
  rm -rf "$NODE_HOME"
  mkdir -p "$NODE_HOME"
  tar -xzf "$tmp/$archive" -C "$tmp"
  cp -R "$tmp/node-v${NODE_VERSION}-${NODE_ARCH}/." "$NODE_HOME/"
fi

if [ ! -x "$DSH_BIN" ]; then
  echo '正在安装 DSH…'
  "$NPM_BIN" install -g @deepseek-ai/dsh --loglevel=error --no-fund --no-audit
fi

if [ ! -x "$DSH_BIN" ]; then
  echo "DSH 安装完成但未找到：$DSH_BIN"
  echo "npm 全局目录：$("$NPM_BIN" prefix -g 2>/dev/null || echo '未知')"
  read -r -p '按 Enter 退出。' _
  exit 3
fi

echo 'Node.js 与 DSH 已准备好，进入北邮 API 配置。'
read -r -s -p '请输入 BUPT API Key（输入不会显示）：' BUPT_API_KEY
echo
if [ -z "$BUPT_API_KEY" ]; then
  echo 'API Key 不能为空。'
  read -r -p '按 Enter 退出。' _
  exit 1
fi
printf '%s\n' "$BUPT_API_KEY" | DSH_NODE_HOME="$NODE_HOME" DSH_HOME="${DSH_HOME:-$HOME/.dsh}" BUPT_PROBE=1 "$NODE_BIN" "$SCRIPT_DIR/configure.mjs"
unset BUPT_API_KEY

mkdir -p "${DSH_HOME:-$HOME/.dsh}"
if ! curl -sS --max-time 1 -o /dev/null http://127.0.0.1:3080/ >/dev/null 2>&1; then
  echo '正在启动 DSH Web…'
  nohup "$DSH_BIN" web --port 3080 >"${DSH_HOME:-$HOME/.dsh}/bupt-dsh.log" 2>&1 &
  dsh_pid=$!
  for _ in $(seq 1 70); do
    if curl -sS --max-time 1 -o /dev/null http://127.0.0.1:3080/ >/dev/null 2>&1; then break; fi
    if ! kill -0 "$dsh_pid" 2>/dev/null; then break; fi
    sleep 0.5
  done
fi

if curl -sS --max-time 1 -o /dev/null http://127.0.0.1:3080/ >/dev/null 2>&1; then
  open http://127.0.0.1:3080
  echo '完成：已打开 http://127.0.0.1:3080'
else
  echo 'DSH 未在预期时间内打开，请查看 ~/.dsh/bupt-dsh.log。'
  tail -n 20 "${DSH_HOME:-$HOME/.dsh}/bupt-dsh.log" 2>/dev/null || true
fi
read -r -p '按 Enter 退出。' _
